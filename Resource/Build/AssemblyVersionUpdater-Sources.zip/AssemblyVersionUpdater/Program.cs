﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace AssemblyVersionUpdater
{
    class Program
    {
        private const string AssemblyVersionPattern = @"AssemblyVersion\(\""\d+.\d+.\d+.\d+\""\)";
        private const string AssemblyFileVersionPattern = @"AssemblyFileVersion\(\""\d+.\d+.\d+.\d+\""\)";

        private const string VersionPattern = @"v\:(\d+.\d+.\d+.\d+)";

        static void Main(string[] args)
        {
            Console.WriteLine("AssemblyInfo.cs file fix utility.");
            #region Parse commandline arguments
            if (args.Length < 2) return;

            var solutionDir = args[0].Substring(3);
            if (!Directory.Exists(solutionDir))
            {
                Console.WriteLine(solutionDir);
                Console.WriteLine(@"Solution directory doesn't exist. Provide new solution directory path and try again.");
                Console.WriteLine(@"Ex. /d:""C:\Projects\FooProject""");
                return;
            }

            var reg = new Regex(VersionPattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
            if (!reg.IsMatch(args[1]))
            {
                Console.WriteLine("Assembly version format is wrong! Provide valid assembly version, please.\r\n Ex: /v:\"2.5.0.0\"");
                return;
            }

            var version = reg.Match(args[1]).Groups[1].Value;

            
            #endregion

            #region AssemblyInfo.cs file fix
            var solutionDirectory = new DirectoryInfo(solutionDir);

            var files = solutionDirectory.GetFiles("*AssemblyInfo.cs", SearchOption.AllDirectories);

            var regex1 = new Regex(AssemblyVersionPattern);
            var regex2 = new Regex(AssemblyFileVersionPattern);

            // fix AssemblyVersion and AssemblyFileVersion in all AssemblyInfo.cs
            foreach (var fileInfo in files)
            {
                Console.WriteLine("File " + fileInfo.FullName + " modified.");

                var fileContent = File.ReadAllText(fileInfo.FullName);

                var newFileContent =
                    regex1.Replace(fileContent,
                                   String.Format(@"AssemblyVersion(""{0}"")", version));
                newFileContent =
                    regex2.Replace(newFileContent,
                                   String.Format(@"AssemblyFileVersion(""{0}"")", version));

                File.WriteAllText(fileInfo.FullName, newFileContent);
            } 
            #endregion
        }
    }
}
